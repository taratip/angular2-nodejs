var Message = (function () {
    function Message(content, username, messageId, userId) {
        this.content = content;
        this.username = username;
        this.messageId = messageId;
        this.userId = userId;
    }
    return Message;
}());
export { Message };
